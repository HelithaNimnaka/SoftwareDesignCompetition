using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using SimpleJSON;
using TMPro;

public class loadUserDataAndSet : MonoBehaviour
{
    public TextMeshProUGUI firstName;
    public TextMeshProUGUI lastName;
    public TextMeshProUGUI userName;
    public TextMeshProUGUI nic;
    public TextMeshProUGUI phoneNumber;
    public TextMeshProUGUI email;

    


    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(GetRequest("http://20.15.114.131:8080/api/user/profile/view"));
        Debug.Log("lsjflskdjf");
    }

    IEnumerator GetRequest(string url)
    {
        using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
        {
            // Add the authentication token to the request headers
            webRequest.SetRequestHeader("Authorization", "Bearer " + StaticData.token);

            // Send the request and wait for a response
            yield return webRequest.SendWebRequest();
            string resultJson = webRequest.downloadHandler.text;
            JSONNode jsonNode = JSON.Parse(resultJson);
            StaticData.firstName_ = jsonNode["user"]["firstname"];
            StaticData.lastName_ = jsonNode["user"]["lastname"];
            StaticData.userName_ = jsonNode["user"]["username"];
            StaticData.nic_ = jsonNode["user"]["nic"];
            StaticData.phoneNumber_ = jsonNode["user"]["phoneNumber"];
            StaticData.email_ = jsonNode["user"]["email"];


            if (webRequest.result == UnityWebRequest.Result.Success)
            {
                if (StaticData.firstName_ == "") {
                    firstName.text = "-";
                }
                else
                {
                    firstName.text = StaticData.firstName_;
                }
                if (StaticData.lastName_ == "") {
                    lastName.text = "-";
                }
                else
                {
                    lastName.text = StaticData.lastName_;
                    
                }
                if (StaticData.userName_ == "") {
                    userName.text = "-";
                }
                else
                {
                    userName.text = StaticData.userName_;
                    
                }
                if (StaticData.nic_ == "") {
                    nic.text = "-";
                }
                else
                {
                    nic.text = StaticData.nic_;
                    
                }
                if (StaticData.phoneNumber_ == "") {
                    phoneNumber.text = "-";
                }
                else
                {
                    phoneNumber.text = StaticData.phoneNumber_;
                    
                }
                if (StaticData.email_ == "") {
                    email.text = "-";
                }
                else
                {
                    email.text = StaticData.email_;
                    
                }

            }
            else
            {
                // Request failed, log the error
                Debug.LogError("Error: " + webRequest.error);
            }
        }
    }
}
