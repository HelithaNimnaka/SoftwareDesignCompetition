using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class loadUserProfile : MonoBehaviour
{
    public void userProfile()
    {
        SceneManager.LoadSceneAsync(2);
    }
}
