using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class back : MonoBehaviour
{
    public void mainMenu()
    {
        SceneManager.LoadSceneAsync(1);
    }
    public void edit()
    {
        SceneManager.LoadSceneAsync(3);
    }
}
