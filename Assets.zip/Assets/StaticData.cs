using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StaticData : MonoBehaviour
{
    public static string token;
    public static string firstName_;
    public static string lastName_;
    public static string userName_;
    public static string nic_;
    public static string phoneNumber_;
    public static string email_;
}
