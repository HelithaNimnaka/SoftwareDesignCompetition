using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;


public class editandsavedata : MonoBehaviour
{
    public TMP_InputField firstNameInput;
    public TMP_InputField lastNameInput;
    public TMP_InputField userNameInput;
    public TMP_InputField nicInput;
    public TMP_InputField phoneNumberInput;
    public TMP_InputField emailInput;

    public void save()
    {
        if (firstNameInput.text != "")
        {
            StaticData.firstName_ = firstNameInput.text;
        }
        if (lastNameInput.text != "")
        {
            StaticData.lastName_ = lastNameInput.text;
        }
        if (userNameInput.text != "")
        {
            StaticData.userName_ = userNameInput.text;
        }
        if (nicInput.text != "")
        {
            StaticData.nic_ = nicInput.text;
        }
        if (phoneNumberInput.text != "")
        {
            StaticData.phoneNumber_ = phoneNumberInput.text;
        }
        if (emailInput.text != "")
        {
            StaticData.email_ = emailInput.text;
        }



        // Serialize the dictionary to a JSON string
        string jsonPayload = "{\"firstname\":\"" + StaticData.firstName_ + "\",\"lastname\":\"" + StaticData.lastName_ + "\",\"nic\":\"" + StaticData.nic_ + "\",\"phoneNumber\":\"" + StaticData.phoneNumber_ + "\",\"email\":\"" + StaticData.email_ + "\"}";

        Debug.Log(jsonPayload);
        StartCoroutine(PutRequest("http://20.15.114.131:8080/api/user/profile/update", jsonPayload));
        
    }
    IEnumerator PutRequest(string url, string jsonPayload)
    {
        NewUserData ChangedUserData = new NewUserData();
        ChangedUserData.firstname = StaticData.firstName_;
        ChangedUserData.lastname = StaticData.lastName_;
        ChangedUserData.nic = StaticData.nic_;
        ChangedUserData.phoneNumber = StaticData.phoneNumber_;
        ChangedUserData.email = StaticData.email_;

        string jsonUserData = JsonUtility.ToJson(ChangedUserData);
        byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonUserData);
        string updateurl = "http://20.15.114.131:8080/api/user/profile/update";
        UnityWebRequest request1 = UnityWebRequest.Put(updateurl, bodyRaw);
        request1.SetRequestHeader("Authorization", "Bearer " + StaticData.token);
        request1.SetRequestHeader("Content-Type", "application/json");
        yield return request1.SendWebRequest();

        if (request1.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("User data updated successfully!");
            SceneManager.LoadSceneAsync(2);
        }
        else
        {
            Debug.LogError("Error updating user data: " + request1.error);
        }
    }

    private class NewUserData
    {
        public string firstname;
        public string lastname;
        public string nic;
        public string phoneNumber;
        public string email;
    }
}
