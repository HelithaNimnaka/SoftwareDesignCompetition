using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class mcq : MonoBehaviour
{
   
    public void LoadMcqWebpage()
    {
        Application.OpenURL(" http://localhost:5173/");
    }

    
}
