rootProject.name = "scoresHandling"
