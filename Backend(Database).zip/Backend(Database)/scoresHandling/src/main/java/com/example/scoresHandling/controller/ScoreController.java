package com.example.scoresHandling.controller;

import com.example.scoresHandling.model.Score;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/scores")
public class ScoreController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping
    public List<Score> getAllScores() {
        String sql = "SELECT * FROM t_score";
        return jdbcTemplate.query(sql, (resultSet, rowNum) ->
                new Score(resultSet.getString("name"), resultSet.getInt("score")));
    }

    @PostMapping
    public void addScore(@RequestBody Score score) {
        String sql = "INSERT INTO t_score (name, score) VALUES (?, ?)";
        jdbcTemplate.update(sql, score.getName(), score.getScore());
    }

}
