package com.example.scoresHandling.controller;

import com.example.scoresHandling.model.Score;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/unity")
public class UnityController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostMapping
    public String addScore(@RequestBody String name) {
        // Check if the name already exists in the database
        String query = "SELECT COUNT(*) FROM t_score WHERE name = ?";
        int count = jdbcTemplate.queryForObject(query, Integer.class, name);

        // If count is greater than 0, the name already exists
        if (count > 0) {
            return "Name already exists: " + name;
        } else {
            // Insert the new score into the database
            // Adjust this part according to your actual Score entity and database schema
            // jdbcTemplate.update("INSERT INTO t_score (name) VALUES (?)", name);
            // Or call a service method to handle adding the score
            // scoreService.addScore(name);
            return "Name does not exists: " + name;
        }
    }
}
