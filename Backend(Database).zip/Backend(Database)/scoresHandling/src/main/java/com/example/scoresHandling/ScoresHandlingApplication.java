package com.example.scoresHandling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScoresHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScoresHandlingApplication.class, args);
	}

}
