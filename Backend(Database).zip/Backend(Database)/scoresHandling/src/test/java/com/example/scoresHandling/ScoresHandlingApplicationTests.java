package com.example.scoresHandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScoresHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
